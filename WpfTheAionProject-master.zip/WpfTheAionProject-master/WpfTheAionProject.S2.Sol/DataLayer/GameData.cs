﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfTheAionProject.Models;

namespace WpfTheAionProject.DataLayer
{
    /// <summary>
    /// static class to store the game data set
    /// </summary>
    public static class GameData
    {
        public static Player PlayerData()
        {
            return new Player()
            {
                Id = 1,
                Name = "Dostya",
                Age = 43,
                Race = Character.RaceType.Cybran,
                Health = 100,
                Lives = 1,
                FactionAcceptence = 10,
                ThreatLevelModifyer = 10,
                LocationId = 0,

                Inventory = new ObservableCollection<GameItem>()
                {
                    GameItemById(2001),
                    GameItemById(2003)
                }
            };
        }
        private static GameItem GameItemById(int id)
        {
            return StandardGameItems().FirstOrDefault(i => i.Id == id);
        }

        public static List<string> InitialMessages()
        {
            return new List<string>()
            {
                "XDXDXDXD"
            };
        }
        private static Npc NpcById(int id)
        {
            return Npcs().FirstOrDefault(i => i.Id == id);
        }
        public static GameMapCoordinates InitialGameMapLocation()
        {
            return new GameMapCoordinates() { Row = 0, Column = 0 };
        }

        public static Map GameMap()
        {
            int rows = 3;
            int columns = 4;



            Map gameMap = new Map(rows, columns);

            gameMap.StandardGameItems = StandardGameItems();
            //
            // row 1
            //
            gameMap.MapLocations[0, 0] = new Location()
            {
                Id = 4,
                Name = "Bunks",
                Description = "This is your faciton's sleeping quarters and where you will return every in game day to rest your characeter," +
                  "This is one of the only safe place in the game. (If your threat level is high you cannot be attacked here) ",
                Accessible = true,
                ThreatLevel = 0,
                GameItems = new ObservableCollection<GameItem>
                {
                    GameItemById(4002),
                    GameItemById(4003)
                },
              
            };
            gameMap.MapLocations[0, 1] = new Location()
            {
                Id = 1,
                Name = " Headquarters",
                Description = "This is your faciton's diplomatic headquarters and where you will return every in game day to rest your characeter," +
                  "This is the only safe place in the game. (If your threat level is high you cannot be attacked here) " +
                  "This is where you will get your diplomatic Missions",
                Accessible = true,
                ThreatLevel = 0,
              
            };

            //
            // row 2
            //
            gameMap.MapLocations[1, 1] = new Location()
            {
                Id = 2,
                Name = "Transit Station",
                Description = "This is the Cybran transit station that will bring you to the meeting place or to the markets or shipyards that ",
                Accessible = true,
                ThreatLevel = 10
            };
          
            gameMap.MapLocations[1, 2] = new Location()
            {
                Id = 2,
                Name = "Train",
                Description = "This is the train that carries you between the Faction's headquarters",
                Accessible = false,
                ThreatLevel = 50,
                RequiredRelicId = 4003,
              
            };
            gameMap.MapLocations[1, 1] = new Location()
            {
                Id = 1,
                Name = "Microsoft Store",
                ModifyLives = -1,
            Description = "This is a store for the interplantary company known as microsoft that may or may not sell illegal items, You must enter to go to the transit station",
                Accessible = false,
                ThreatLevel = 10,
                RequiredRelicId = 4003
            };
            //
            // row 3
            //
            gameMap.MapLocations[2, 2] = new Location()
            {
                Id = 3,
                Name = "The Aeon Headquarters",
                Description = "This is where the leader of the Aeon resides, Princess Bruke and her Advisors",
                Accessible = false,
                ThreatLevel = 20,
                ModifyHealth = 50,
                RequiredRelicId = 4003,
                Npcs = new ObservableCollection<Npc>()
                {
                    NpcById(1003)
                },
                  GameItems = new ObservableCollection<GameItem>
                {
                    GameItemById(4001)                    
                },
            };
            gameMap.MapLocations[2, 3] = new Location()
            {
                Id = 5,
                Name = "The Cybran Battle Report Room",
                Description = "This is where the Cybrans hold their battle reports",
                Accessible = false,
                ThreatLevel = 20,
                ModifyHealth = 50,
                RequiredRelicId = 4003,
                
            };
            gameMap.MapLocations[1, 3] = new Location()
            {
                Id = 4,
                Name = "Cybran Headquarters",
                Description = "The cybran headquarters where you will meet the leader of the cybrans. Docter Brackman.",
                Accessible = true,
                ThreatLevel = 10,
                Npcs = new ObservableCollection<Npc>()
                {
                    NpcById(1001),
                    NpcById(1002)
                },
                  GameItems = new ObservableCollection<GameItem>
                {
                    GameItemById(4004),
                },

            };
           


            return gameMap;
        }
        public static List<GameItem> StandardGameItems()
        {
            return new List<GameItem>()
            {
                new Treasure(2001, "Gold Coin", 10, Treasure.TreasureType.Coin, "24 karat gold coin, why do you have this?", 1),
                new Treasure(2002, "Small Diamond", 50, Treasure.TreasureType.BattleReport, "A small pea-sized diamond of various colors.", 1),
                new Treasure(2003, "XD Manuscript", 10, Treasure.TreasureType.Manuscript, "Reportedly stolen during the Zantorian raids of of the 4th dynasty, it is said to contain information about early galactic technologies.", 5),
                new Treasure(3002, "Base Keycard", 100, Treasure.TreasureType.Keycard,"This is your keycard to both enter and exit the headquarters", 5),
                new Relic(4004, "Red Key", 5, "Red Keycard, Keycard for Cybran locaitons", 5, "You have opened the cybran battle report door", Relic.UseActionType.OPENLOCATION),
                new Relic(4001, "Green Key", 5, "Green Keycard, Keycard for Aeon locaitons", 5, "You have opened the Aeon battle report door", Relic.UseActionType.OPENLOCATION),
                 new Relic(4005, "Blue Key", 5, "Blue Keycard, Keycard for UEF locaitons", 5, "You have opened the UEF battle report door", Relic.UseActionType.OPENLOCATION),
                new Relic(4002, "Distress Becon", 5, "A simple pad with a red button on it that you would press to call security", 5, "You are immedilty gunned down by assassins it wasnt a distress becon", Relic.UseActionType.KILLPLAYER),
                new Relic(4003, "Train Ticket", 5, "Train Ticket used to get on trains?", 5, "You have gotten access to the train you may get on whenever you want", Relic.UseActionType.OPENLOCATION)

            };
        }
        public static List<Npc> Npcs()
        {
            return new List<Npc>()
            {
                

                new Citizen()
                {
                    Id = 1001,
                    Name = "Doctor Brackman",
                    Race = Character.RaceType.Cybran,
                    Description = "Leader of the Cybrans",
                    Messages = new List<string>()
                    {
                        "Good it is a good time that you arrived diplomat,  take this keycard and go to the Aoen you must speak with them about the assult on Contra 2"
                    }
                },

                new Citizen()
                {
                    Id = 1002,
                    Name = "Cybran Champion",
                    Race = Character.RaceType.Cybran,
                    Description = "An imposing Figure in the background garbed in dark armor covering his face",
                    Messages = new List<string>()
                    {
                        "Silence"
                    }
                },
                new Citizen()
                {
                    Id = 1003,
                    Name = "Princess Bruke",
                    Race = Character.RaceType.Aeon,
                    Description = "Leader of the Aeon, not only politcally but spiritually as well",
                      
            
            Messages = new List<string>()
                    {
                        "Evening diplomat, take this keycard and leave it has access to the room with the battle report for brackman. Now leave my advisors must console me about the recent attack on vertia "+
                        "There should be a battle report in the bunks awaiting you."
                    }
                },

                new Citizen()
                {
                    Id = 1004,
                    Name = "Commander Rhiza",
                    Race = Character.RaceType.Aeon,
                    Description = "A fanatic of the Aoen commanders",
                    Messages = new List<string>()
                    {
                        "GLOURIUS"
                    }
                },
                 new Citizen()
                {
                    Id = 1005,
                    Name = "UEF Leader",
                    Race = Character.RaceType.UEF,
                    Description = "A tall women of respectable stature.",
                    Messages = new List<string>()
                    {
                        "GLOURIUS"
                    }
                },
                  new Citizen()
                {
                    Id = 1006,
                    Name = "UEF XD",
                    Race = Character.RaceType.UEF,
                    Description = "A tall women of respectable stature.",
                    Messages = new List<string>()
                    {
                        "GLOURIUS"
                    }
                }
            };
        }
    }
}
