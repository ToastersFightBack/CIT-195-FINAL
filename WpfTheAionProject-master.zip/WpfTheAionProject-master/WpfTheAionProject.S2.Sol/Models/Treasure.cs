﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfTheAionProject.Models
{
    class Treasure : GameItem
    {
        public enum TreasureType
        {
            Coin,
            Keycard,
            Manuscript,
            BattleReport,
            Map
        }

        public TreasureType Type { get; set; }

        public Treasure(int id, string name, int value, TreasureType type, string description, int threatLevel)
            : base(id, name, value, description, threatLevel)
        {
            Type = type;
        }

        public override string InformationString()
        {
            return $"{Name}: {Description}\nValue: {Value}";
        }
    }
}
